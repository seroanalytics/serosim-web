library(testthat)
library(serosim)

test_check("serosim")
