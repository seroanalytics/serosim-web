## usethis namespace: start
#' @useDynLib serosim, .registration = TRUE
## usethis namespace: end
NULL